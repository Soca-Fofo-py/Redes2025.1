import pygame
import time

pygame.init()
screenW = 800
screenH = 600
gameDisplay = pygame.display.set_mode((screenW,screenH))
pygame.display.set_caption('Jacare vs Pato')

patoW = 60
patoH = 40
patoX = 600
patoY = 400 - patoH
patoImg = pygame.image.load('pato.jpg')
patoImg = pygame.transform.scale(patoImg, (patoW, patoH))

vidas = 3
vidasW = patoW // 2
vidasH = patoH // 2
vidasX = screenW - (vidasW + 5) * vidas
vidasY = 20
patoVida = pygame.transform.scale(patoImg, (vidasW, vidasH))

jacareW = 100
jacareH = 40
jacareY = 400 - jacareH//2
jacareX = 100
jacareImg = pygame.image.load('jacare.jpg')
jacareImg = pygame.transform.scale(jacareImg, (jacareW, jacareH))


marX = 0
marY = 400
marW = screenW
marH = screenH - marY
mar1Img = pygame.image.load('oceano-1.jpg')
mar1Img = pygame.transform.scale(mar1Img, (marW, marY))

mar2Img = pygame.image.load('oceano-2.jpg')
mar2Img = pygame.transform.scale(mar2Img, (marW, marY))
maresImg = (mar1Img, mar2Img)

ceuX = 0
ceuY = 0
ceuW = screenW
ceuH = marY
ceuImg = pygame.image.load('ceu.jpg')
ceuImg = pygame.transform.scale(ceuImg, (marW, marY))

frame = 0
paused = False

while vidas > 0:
    # ler o teclado e se tiver o espaco, paused = True
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            break
        elif evento.type == pygame.KEYDOWN:
             if evento.key == pygame.K_SPACE:
                paused = not paused
             elif evento.key == pygame.K_UP:
                patoY -= 5

    if paused == False:
        # Desenha as imagens
        gameDisplay.blit(ceuImg, (ceuX, ceuY))
        gameDisplay.blit(maresImg[frame%2], (marX, marY))

        gameDisplay.blit(patoImg, (patoX, patoY))
        gameDisplay.blit(jacareImg, (jacareX, jacareY))

        vidaX = vidasX
        for i in range(vidas):
            gameDisplay.blit(patoVida, (vidaX, vidasY))
            vidaX += vidasW + 5

        pygame.display.update()

        patoX -= 5
        if patoX < 0:
            patoX = screenW

        if patoY < (marY - patoH):
            if frame % 5 == 0:
                patoY += 5

        if (jacareX+jacareW) >= patoX and (patoY+patoH) >= jacareY:
            vidas -= 1
            patoX = 600
            patoY = 400 - patoH
    frame += 1
    time.sleep(0.1)

pygame.quit()